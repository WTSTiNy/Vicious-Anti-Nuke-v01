# Imports
import discord, datetime, asyncio, re, copy, pymongo, os
from dateutil.relativedelta import relativedelta
from discord.ext import commands, tasks
from colorama import Fore as V

# ENV/Hidden Files
mongo_key = os.environ.get("key")
ID = os.environ.get("ID")

# Shortened
TiNy = V.LIGHTCYAN_EX
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()
time_regex = re.compile("(?:(\d{1,5})(h|s|m|d))+?")
time_dict = {"h": 3600, "s": 1, "m": 60, "d": 86400}

def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID

# MongoDB Key Startup
try:
  mongoDB = pymongo.MongoClient(mongo_key, tls=True, tlsAllowInvalidCertificates=False)
  blacklisted = mongoDB.get_database("Vicious").get_collection("Blacklisted")
except:
  print("{}[-] Invalid MongoDB Key".format(ERRORS))

# Definition/Creating the Cog
class TimeConverter(commands.Converter):
    async def convert(self, ctx, argument):
        args = argument.lower()
        matches = re.findall(time_regex, args)
        time = 0
        for key, value in matches:
            try:
                time += time_dict[value] * float(key)
            except KeyError:
                raise commands.BadArgument(
                    f"{value} is an invalid time key! h|m|s|d are valid arguments"
                )
            except ValueError:
                raise commands.BadArgument(f"{key} is not a number!")
        return round(time)

class Moderation(commands.Cog):
  def __init__(self, vicious):
    self.vicious = vicious
    self.mute_task = self.check_current_mutes.start()
    cog_name = self.__class__.__name__
    print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

  def cog_unload(self):
    self.mute_task.cancel()

# Events (Including Looping and On_Connect)
  @tasks.loop(minutes=5)
  async def check_current_mutes(self):
        currentTime = datetime.datetime.now()
        mutes = copy(commands.muted_users)
        for key, value in mutes.items():
            if value['muteDuration'] is None:
                continue

            unmuteTime = value['mutedAt'] + relativedelta(seconds=value['muteDuration'])

            if currentTime >= unmuteTime:
                guild = commands.get_guild(value['guildId'])
                member = guild.get_member(value['_id'])

                role = discord.utils.get(guild.roles, name="Muted")
                if role in member.roles:
                    await member.remove_roles(role)
                    print(f"Unmuted: {member.display_name}")

                await commands.mutes.delete(member.id)
                try:
                    commands.muted_users.pop(member.id)
                except KeyError:
                    pass
# Command and Event Checks
  @check_current_mutes.before_loop
  async def before_check_current_mutes(self):
        await commands.wait_until_ready()

# Cog Commands
  @commands.command(
        name='mute',
        description="Mutes a member for `X` amount of time",
        ussage='<@user> [time]'
    )
  @commands.has_permissions(manage_roles=True)
  async def mute(self, ctx, member: discord.Member, *, time: TimeConverter=None):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
        role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not role:
            await ctx.send("No muted role was found! Please create one called `Muted`")
            return

        try:
            if commands.muted_users[member.id]:
                await ctx.send("This user is already muted")
                return
        except KeyError:
            pass

        data = {
            '_id': member.id,
            'mutedAt': datetime.datetime.now(),
            'muteDuration': time or None,
            'mutedBy': ctx.author.id,
            'guildId': ctx.guild.id,
        }
        await commands.mutes.upsert(data)
        commands.muted_users[member.id] = data

        await member.add_roles(role)

        if not time:
            await ctx.send(f"Muted {member.display_name}")
        else:
            minutes, seconds = divmod(time, 60)
            hours, minutes = divmod(minutes, 60)
            if int(hours):
                await ctx.send(
                    f"Muted {member.display_name} for {hours} hours, {minutes} minutes and {seconds} seconds"
                )
            elif int(minutes):
                await ctx.send(
                    f"Muted {member.display_name} for {minutes} minutes and {seconds} seconds"
                )
            elif int(seconds):
                await ctx.send(f"Muted {member.display_name} for {seconds} seconds")

        if time and time < 300:
            await asyncio.sleep(time)

            if role in member.roles:
                await member.remove_roles(role)
                await ctx.send(f"Unmuted `{member.display_name}`")

            await commands.mutes.delete(member.id)
            try:
                commands.muted_users.pop(member.id)
            except KeyError:
                pass

  @commands.command(name='unmute', description="Unmute a given member", usage='<@user>'
    )
  @commands.has_permissions(manage_roles=True)
  async def unmute(self, ctx, member: discord.Member):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
        role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not role:
            await ctx.send("No muted role was found! Please create one called `Muted`")
            return

        await commands.mutes.delete(member.id)
        try:
            commands.muted_users.pop(member.id)
        except KeyError:
            pass

        if role not in member.roles:
            embed = discord.Embed(description="`{}#{}` isn't Muted".format(member.name, member.discriminator), color=color)
            await ctx.send(embed=embed)
            return

        await member.remove_roles(role)
        await ctx.send(f"Unmuted `{member.display_name}`")

  @commands.command(name="kick", description="Kicks a given user", usage="<@user> [reason]")
  @commands.guild_only()
  @commands.has_guild_permissions(ban_members=True)
  async def kick(self, ctx, member: discord.Member, *, reason="N/A"):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
      await ctx.guild.kick(user=member, reason="{} || Kicked by {}".format(reason, ctx.author.name))
      embed = discord.Embed(description="**__Kicked:__** `{}#{}`\n**__Reason:__** `{}`".format(member.user.name, member.user.discriminator, reason), color=color)
      embed.set_footer(text="Kicked by: {}" + ctx.author.name, icon_url=ctx.message.author.avatar_url)
      await ctx.send(embed=embed)

  @commands.command(name="ban", description="Bans a given user", usage="<@user> [reason]")
  @commands.guild_only()
  @commands.has_guild_permissions(ban_members=True)
  async def ban(self, ctx, member: discord.Member, *, reason="N/A"):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
        await ctx.guild.ban(user=member, reason="{} || Banned by {}".format(reason, ctx.author.name))

        # Using our past episodes knowledge can we make the log channel dynamic?
        embed = discord.Embed(description="**__Banned:__** `{}#{}`\n**__Reason:__** `{}`".format(member.user.name, member.user.discriminator, reason), color=color)
        embed.set_footer(text="Banned by: {}" + ctx.author.name, icon_url=ctx.message.author.avatar_url)
        await ctx.send(embed=embed)

  @commands.command(name="unban", description="Unbans a given user", usage="<@user> [reason]")
  @commands.guild_only()
  @commands.has_guild_permissions(ban_members=True)
  async def unban(self, ctx, member, *, reason="N/A"):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:

        member = await commands.fetch_user(int(member))
        await ctx.guild.unban(member, reason="{} || Unbanned by {}".format(reason, ctx.author.name))

        embed = discord.Embed(description="**__Unbanned:__** `{}#{}`\n**__Reason:__** `{}`".format(member.user.name, member.user.discriminator, reason), color=color)
        embed.set_footer(text="Unbanned by: {}" + ctx.author.name, icon_url=ctx.message.author.avatar_url)
        await ctx.send(embed=embed)


# Channel Moderation commands

  @commands.command(name="lock", description="Locks a given channel", usage="<#channel> [reason]", aliases=["lockdown"])
  @commands.has_permissions(manage_channels=True)
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def lock(self, ctx, channel: discord.TextChannel=None, *, reason="N/A"):
      if ctx.message.author.id == blacklisted:
        return
        if ctx.message.author.vicious:
          return
        else:
          ow = ctx.channel.overwrites_for(ctx.guild.default_role)
          ow.send_messages = False
          await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=ow)
          lock = discord.Embed(description="**__Locked:__** <#{}>\n**__Moderator:__** {}\n**__Reason:__** `{}`".format(ctx.channel.id, ctx.author, reason))
          await ctx.send(embed=lock)
      else:
        mpembed = discord.Embed(description="**__Error:__** `You are missing permissions to MANAGE_CHANNELS`", color=color)
        mpembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
        await ctx.send(embed=mpembed)

  @commands.command()
  @commands.has_permissions(manage_channels=True)
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def unlock(self, ctx, channel: discord.TextChannel=None):
      if ctx.message.author.id == blacklisted:
        return
        if ctx.message.author.vicious:
          return
        else:
          ow = ctx.channel.overwrites_for(ctx.guild.default_role)
          ow.send_messages = True
          await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=ow)
          lock = discord.Embed(description="**__Unlocked:__** <#{}>\n**__Moderator:__** {}".format(ctx.channel.id, ctx.author))
          await ctx.send(embed=lock)
      else:
        mpembed = discord.Embed(description="**__Error:__** `You are missing permissions to MANAGE_CHANNELS`", color=color)
        mpembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
        await ctx.send(embed=mpembed)

# Cog Adding and Setup with Our Variable
def setup(vicious):
  vicious.add_cog(Moderation(vicious))