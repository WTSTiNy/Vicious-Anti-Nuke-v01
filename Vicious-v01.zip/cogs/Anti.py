# Imports
import discord, pymongo, os
from discord.ext import commands
from discord.ext.commands import check
from colorama import Fore as V

# ENV/Hidden Files
mongo_key = os.environ.get("key")
token = os.environ.get("token")
ID = os.environ.get("ID")
prefix = os.environ.get("prefix")

# Shortened 1
TiNy = V.LIGHTCYAN_EX
Tali = V.MAGENTA
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()

class Anti(commands.Cog):
  def __init__(self, vicious):
    self.vicious = vicious
    cog_name = self.__class__.__name__
    print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

# MongoDB Key Startup
try:
  mongoDB = pymongo.MongoClient(mongo_key, tls=True, tlsAllowInvalidCertificates=False)
  try:
    whitelisted = mongoDB.get_database("Vicious").get_collection("Whitelisted")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try: 
    punishment = mongoDB.get_database("Vicious").get_collection("Punishment")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    blacklisted = mongoDB.get_database("Vicious").get_collection("Blacklisted")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    prefixes = mongoDB.get_database("Vicious").get_collection("Prefixes")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
except:
  print("{}[-] Invalid MongoDB Key".format(ERRORS))


  @commands.command()
  @check.guild_owner()
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def setup(self, ctx, channel: discord.TextChannel=None):
      if ctx.message.author.id == blacklisted:
        return
      if ctx.message.author.vicious:
        return
      else:
        logss = mongoDB.find_one({"guildid": ctx.guild.id})["logs"]
        embed = discord.Embed(description="**__Creating Vicious's Anti Nuke Setup__**", color=color)
        embed.set_footer(text="{}".format(ctx.author), icon_url=ctx.author.avatar_url)
        edit = await ctx.send(embed=embed)
        
        embed2 = discord.Embed(description="**__Creating Vicious's Anti Nuke Setup__**")
        embed2.add_field(name="__`Finding logging channel...`__")
        embed2.set_footer(text="{}".format(ctx.author), icon_url=ctx.author.avatar_url)

  @commands.command(aliases="wl")
  @check.guild_owner()
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def whitelist(self, ctx, member: discord.Member=None):
      if ctx.message.author.id == blacklisted:
        return
      if ctx.message.author.vicious:
        return
      else:
        if not mongoDB.find_one({"guildid": ctx.guild.id}):
          wguild = commands.get_guild(ctx.guild.id)
          commands.Creating(wguild.owner.id, wguild.id)
          if member is None:
            nembed = discord.Embed(description="**__Error:__** `You must mention a user to whitelist`", color=color)
            nembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
            await ctx.send(embed=nembed)
          else:
            whitelisted = mongoDB.find_one({"guildid": ctx.guild.id})["whitelisted"]
            if member.id in whitelisted:
              embed = discord.Embed(description="**__Error:__** `This user has already been whitelisted`", color=color)
              embed.set_footer(text="{}".format(ctx.author), icon_url=ctx.author.avatar_url)
            else:
              mongoDB.update_one({"guildid": ctx.guild.id}, {"$push":  {"whitelisted": member.id}})
              wembed = discord.Embed(description="**__Whitelisted__** `<@{}>`\n**__Sent By:__** `{}`".format(member.id, ctx.author), color=color)
              await ctx.send(embed=wembed)
        else:
          mpembed = discord.Embed(description="**__Error:__** `Only can the server owner whitelist users here`", color=color)
          mpembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
          await ctx.send(embed=mpembed)

  @commands.command(aliases=["uwl", "rwl", "removewhitelist", "removewhitelisted"])
  @check.guild_owner()
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def unwhitelist(self, ctx, member: discord.Member=None):
      if ctx.message.author.id == blacklisted:
        return
      if ctx.message.author.vicious:
        return
      else:
        if not mongoDB.find_one({"guildid": ctx.guild.id}):
          uwguild = commands.get_guild(ctx.guild.id)
          commands.Creating(uwguild.owner.id, uwguild.id)
          if member is None:
            nembed = discord.Embed(description="**__Error:__** `You must mention a user to unwhitelist`", color=color)
            nembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
            await ctx.send(embed=nembed)
          else:
            whitelisted = mongoDB.find_one({"guildid": ctx.guild.id})["whitelisted"]
            if member.id not in whitelisted:
              embed = discord.Embed(description="**__Error:__** `This user has already been unwhitelisted`", color=color)
              embed.set_footer(text="{}".format(ctx.author), icon_url=ctx.author.avatar_url)
            else:
              mongoDB.update_one({"guildid": ctx.guild.id}, {"$pull":  {"whitelisted": member.id}})
              wembed = discord.Embed(description="**__Unwhitelisted__** `<@{}>`\n**__Sent By:__** `{}`".format(member.id, ctx.author), color=color)
              await ctx.send(embed=wembed)
        else:
          mpembed = discord.Embed(description="**__Error:__** `Only can the server owner unwhitelist users here`", color=color)
          mpembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
          await ctx.send(embed=mpembed)

  @commands.command(aliases="wld")
  @check.guild_owner()
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def whitelisted(ctx):
      if ctx.message.author.id == blacklisted:
        return
      if ctx.message.author.vicious:
        return
      else:
        whitelisted = mongoDB.find_one({"guildid": ctx.guild.id})["whitelisted"]
        for vicious in whitelisted:
              users = commands.get_user(vicious)
              if users == None:
                empty = "Unable to Fetch Whitelisted Users in `{}`".format(ctx.guild.name)
              else:
                empty =+ users.name, users.discriminator
                w =+ "{empty} || {vicious}\n"
                whitelistedusers = discord.Embed(description="**__Whitelisted Users:__**\n\n```{}```".format(w), color=color)
                whitelistedusers.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
                await ctx.send(embed=whitelistedusers)
              if w == None:
                emptyembed = discord.Embed(description="**__Whitelisted Users:__**\n\n```No one is whitelisted except the guild owner```", color=color)
                emptyembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
                await ctx.send(embed=emptyembed)
              else:
                mpembed = discord.Embed(description="**__Error:__** `Only can the server owner view whitelisted users here`", color=color)
                mpembed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
                await ctx.send(embed=mpembed)

# Cog Adding and Setup with Our Variable
def setup(vicious):
  vicious.add_cog(Anti(vicious))