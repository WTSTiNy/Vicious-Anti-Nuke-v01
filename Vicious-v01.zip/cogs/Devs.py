# Imports
import discord, os
from discord.ext import commands
from colorama import Fore as V

# ENV/Hidden Files
ID = os.environ.get("ID")

# Shortened
TiNy = V.LIGHTCYAN_EX
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()

def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID

# Definition/Creating the Cog
class Devs(commands.Cog):
  def __init__(self, vicious):
    self.vicious = vicious
    cog_name = self.__class__.__name__
    print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

      
# Cog Adding and Setup with Our Variable
def setup(vicious):
  vicious.add_cog(Devs(vicious))