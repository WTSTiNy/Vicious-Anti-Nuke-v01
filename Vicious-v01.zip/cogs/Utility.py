# Imports
import discord, pymongo, os, datetime, asyncio, pkg_resources as pkg
from discord.ext import commands
from colorama import Fore as V

# ENV/Hidden Files
mongo_key = os.environ.get("key")
ID = os.environ.get("ID")

# Shortened
TiNy = V.LIGHTCYAN_EX
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()
started = datetime.datetime.utcnow()

def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID

# MongoDB Key Startup
try:
  mongoDB = pymongo.MongoClient(mongo_key, tls=True, tlsAllowInvalidCertificates=False)
  blacklisted = mongoDB.get_database("Vicious").get_collection("Blacklisted")
except:
  print("{}[-] Invalid MongoDB Key".format(ERRORS))

# Definition/Creating the Cog
class Utility(commands.Cog):
  def __init__(self, vicious):
    self.vicious = vicious
    cog_name = self.__class__.__name__
    print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

  @commands.command(aliases=['mc', 'membercount'])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def members(self, ctx): 
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
      everyone = len(ctx.guild.members)
      on = len(list(filter(lambda m: str(m.status) == "online", ctx.guild.members)))
      i = len(list(filter(lambda m: str(m.status) == "idle", ctx.guild.members)))
      dnd = len(list(filter(lambda m: str(m.status) == "dnd", ctx.guild.members)))
      o = len(list(filter(lambda m: str(m.status) == "offline", ctx.guild.members)))
      users = len(list(filter(lambda m: not m.bot, ctx.guild.members)))
      b = len(list(filter(lambda m: m.bot, ctx.guild.members)))
      embed=discord.Embed(title = f"Member Stats:", description=f"""
      **__Total:__** `{everyone}`
      **__Online:__** `{on}`
      **__DND:__** `{dnd}`
      **__Idle: __** `{i}`
      **__Offline:__** `{o}`
      **__Humans:__** `{users}`
      **__Bots:__** `{b}`
      """, color=color)
      embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
      embed.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
      await ctx.send(embed=embed)
  
    @commands.command(aliases=["userinfo", "memberinfo"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.cooldown(1, 2, commands.BucketType.guild)
    async def whois(self, ctx, member:discord.Member =  None):
      if ctx.message.author.id == blacklisted:
        return
      if ctx.message.author.vicious:
        return
      if member is None:
        member = ctx.author
        roles = [role for role in ctx.author.roles]

      else:
            roles = [role for role in member.roles]

      embed = discord.Embed(colour=color)
      embed.set_author(name="{} User Info: ".format(member))
      embed.add_field(name="**__ID:__**", value="`{}`".format(member.id), inline=False)
      embed.add_field(name="**__User Name:__**",value="`{}`".format(member.display_name), inline=False)
      embed.add_field(name="**__Discriminator:__**",value="`{}`".format(member.discriminator), inline=False)
      embed.add_field(name="**__Status:__**", value="`{}`".format(str(member.status).title()), inline=False)
      embed.add_field(name="**__Activity:__**", value=f"{str(member.activity.type).title().split('.')[1]} {member.activity.name}" if member.activity is not None else "`N/A`", inline=False)
      embed.add_field(name="**__Account Registration:__**", value="`{}`".format(member.created_at.strftime("%a, %d, %B, %Y, %I, %M, %p UTC")), inline=False)
      embed.add_field(name="**__Joined At:__**", value="`{}`".format(member.joined_at.strftime("%a, %d, %B, %Y, %I, %M, %p UTC")), inline=False)
      embed.add_field(name=f"Roles [{len(roles)}]", value=" **|** ".join([role.mention for role in roles]), inline=False)
      embed.add_field(name="**__Highest Role:__**", value="`{}`".format(member.top_role), inline=False)
      embed.add_field(name="**__Bot?:__**", value="`{}`".format(member.bot), inline=False)
      embed.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
      embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
      await ctx.send(embed=embed)

  @commands.command(aliases=["time"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def uptime(self, ctx):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
      vicious = datetime.datetime.utcnow() - started
      vicious = str(vicious).split('.')[0]
      embed = discord.Embed(description="**__Vicious Uptime:__**\nUptime: `{}` 🥱💤".format(vicious), color=color)
      embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
      embed.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
      await ctx.send(embed=embed)
    
  @commands.command(aliases=["icon", "serverpfp"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def servericon(self, ctx):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
      try:
        embed = discord.Embed(description="{}'s Server Icon".format(ctx.guild.name),color=color)
        embed.set_image(url=ctx.guild.icon_url)
        embed.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
        await ctx.send(embed=embed)
      except:
        await ctx.send("{}".format(ctx.guild.icon_url))

  @commands.command(aliases=["banner"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def serverbanner(self, ctx):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
      try:
        embed = discord.Embed(description="{}'s Server Banner".format(ctx.guild.name),color=color)
        embed.set_image(url=ctx.guild.banner_url)
        embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
        embed.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
        await ctx.send(embed=embed)
      except:
        await ctx.send("{}".format(ctx.guild.banner_url))
  @commands.command(aliases=["firstmsg"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def firstmessage(self, ctx, channel: discord.TextChannel = None):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
      if channel is None:
        channel = ctx.channel
        first_msg = (await channel.history(limit=1, oldest_msg=True).flatten())[0]
        embed = discord.Embed(description="{}")
        embed.add_field(name="First Message", value=f"[Click Here to Jump to the First Message]({first_msg.jump_url})".format(first_msg.content), color=color)
        embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
        embed.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
        await ctx.send(embed=embed)

  @commands.command(aliases=["av", "pfp"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def avatar(self, ctx, member : discord.Member = None):
    if member is None:
      embed = discord.Embed(description="{}'s Avatar".format(ctx.author.name), color=color)
      embed.set_image(url=ctx.author.avatar_url)
      embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
      embed.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
      await ctx.send(embed=embed)
      return
    else:
      embed2 = discord.Embed(description="{}'s Avatar".format(member), color=color)
      embed2.add_field(name="Animated?:", value="`{}`".format(member.is_avatar_animated()))
      embed2.set_image(url=member.avatar_url)
      embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
      embed2.set_footer(text="{}".format(ctx.author.name), icon_url="{}".format(ctx.avatar_url))
      await ctx.send(embed=embed2)
      return


def setup(vicious):
  vicious.add_cog(Utility(vicious))