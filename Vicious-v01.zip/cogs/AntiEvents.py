# Imports
import discord, os, pymongo, datetime
from discord.ext import commands
from colorama import Fore as V

# Command Checks for Commands
def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID

# ENV/Hidden Files
mongo_key = os.environ.get("key")
token = os.environ.get("token")
ID = os.environ.get("ID")

# Shortened
TiNy = V.LIGHTCYAN_EX
era = V.MAGENTA
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()
prefix = os.environ.get("prefix")
invs = ["discord.gg", "discord.com/invite"]

# Command Toggles (The Old Way)
anti_link = "on" or True

# MongoDB Key Startup
try:
  mongoDB = pymongo.MongoClient(mongo_key, tls=True, tlsAllowInvalidCertificates=False)
  try:
    whitelisted = mongoDB.get_database("Vicious").get_collection("Whitelisted")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try: 
    punishment = mongoDB.get_database("Vicious").get_collection("Punishment")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    blacklisted = mongoDB.get_database("Vicious").get_collection("Blacklisted")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    prefixes = mongoDB.get_database("Vicious").get_collection("Prefixes")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    premium = mongoDB.get_database("Vicious").get_collection("Premium")
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
except:
  print("{}[-] Invalid MongoDB Key".format(ERRORS))

def Creating(guild_owner, serverid):
  database = [whitelisted, punishment, blacklisted, prefixes]
  database.insert_one({
    "whitelisted": [guild_owner],
    "punishment": "ban",
    "blacklisted": None,
    "guildid": serverid,
    "prefix": prefix,
    "premium": premium
  })

def Deleting(guild_owner, serverid):
  database = [whitelisted, punishment, blacklisted, prefixes]
  database.insert_one({
    "whitelisted": [guild_owner],
    "punishment": "ban",
    "blacklisted": None,
    "guildid": serverid,
    "prefix": prefix
  })

class AntiEvents(commands.Cog):
  def __init__(self, vicious):
    self.vicious = vicious
    cog_name = self.__class__.__name__
    print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

  @commands.Cog.listener()
  async def on_message(message):
    global anti_link
    if invs in message.content():
      if invs in message.content.lower():
        if anti_link == "on" or True:
            await message.delete()
            embed = discord.Embed(description="**__Anti-Link__**\n`Don't send invite links` {}".format(message.author.mention))
            await message.channel.send(embed=embed)
            await commands.process_commands(message)

  @commands.command(aliases=["antilink", "anti-link", "anti-url", "antiurl", "invites"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def anti_link(ctx):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    global anti_link
    if anti_link == "off" or False:
        anti_link = "on" or True
        embed = discord.Embed(description="Anti-Link has been **Enabled**", color=color)
        embed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
        await ctx.send(embed=embed)
        return anti_link
    else:
        anti_link = "off" or False
        embedo = discord.Embed(description="Anti-Link has been **Disabled**", color=color)
        embedo.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
        await ctx.send(embed=embedo)
        return anti_link

# Cog Adding and Setup with Our Variable
def setup(vicious):
  vicious.add_cog(AntiEvents(vicious))