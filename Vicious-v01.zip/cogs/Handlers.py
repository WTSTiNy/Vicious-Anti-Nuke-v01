import discord, os, pymongo
from discord.ext import commands
from colorama import Fore as V

# ENV/Hidden Files
ID = os.environ.get("ID")

# Shortened
TiNy = V.LIGHTCYAN_EX
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()

def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID

# Definition/Creating the Cog
class Handlers(commands.Cog):
  def __init__(self, vicious):
    self.vicious = vicious
    cog_name = self.__class__.__name__
    print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

  @commands.Cog.listener()
  async def on_command_error(self, ctx, error, * x):
    if isinstance(error, commands.MissingPermissions):
      try:  
        embed = discord.Embed(description=f"You're Missing Permissions\nRequired Permissions `{(error.missing_perms)}`", color=color)
        await ctx.send(embed=embed)
      except:
        await ctx.send(f"You're Missing Permissions\nRequired Permissions `{(error.missing_perms)}`")
    elif isinstance(error, commands.CommandsOnCooldown):
      try:
        embed = discord.Embed(description=f"You're On Command Cooldown\nTry again in `{round(error.retry_after, 2)}s`", color=color)
        await ctx.send(embed=embed)
      except:
        await ctx.send(f"You're On Command Cooldown\nTry again in `{round(error.retry_after, 2)}s`")
    elif isinstance(error, commands.MissingRequiredArgument):
      try:
        embed = discord.Embed(description=f"You're Missing An Argument\nMissing Arguments for `{ctx.command}`", color=color)
        await ctx.send(embed=embed)
      except:
        await ctx.send(f"You're Missing An Argument\nMissing Arguments for `{ctx.command}`")
    elif isinstance(error, commands.CommandNotFound):
      try:
        embed = discord.Embed(description=f"No Command Found As: `{x}`", color=color)
        await ctx.send(embed=embed)
      except:
        await ctx.send(f"No Command Found As: `{x}`")
    elif isinstance(error, commands.BotMissingPermissions):
      try:
        embed = discord.Embed(description=f"Uh-oh I'm Missing Permssions to `{(error.missing_perms)}`", color=color)
        await ctx.send(embed=embed)
      except:
        await ctx.send(f"Uh-oh I'm Missing Permssions to `{(error.missing_perms)}`")
    elif isinstance(error, commands.NoPrivateMessage):
      try:
          embed = discord.Embed(description=f"You can't use `{ctx.command}` command in DMs", color=color)
          await ctx.author.send(embed=embed)

      except discord.HTTPException:
          pass
      except:
        await ctx.author.send(f"You can't use `{ctx.command}` command in DMs")



# Cog Adding and Setup with Our Variable
def setup(vicious):
  vicious.add_cog(Handlers(vicious))