# Imports
import discord, datetime, asyncio, random, pymongo, os, praw
from discord.ext import commands
from colorama import Fore as V

# ENV/Hidden Files
mongo_key = os.environ.get("key")
ID = os.environ.get("ID")
reddit_key = os.environ.get("reddit_key")

# Shortened
TiNy = V.LIGHTCYAN_EX
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()
uagent = """Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.38 Safari/537.36 Brave/75"""
  # Haxer Man 😈


def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID

# MongoDB Key Startup
try:
  mongoDB = pymongo.MongoClient(mongo_key, tls=True, tlsAllowInvalidCertificates=False)
  blacklisted = mongoDB.get_database("Vicious").get_collection("Blacklisted")
except:
  print("{}[-] Invalid MongoDB Key".format(ERRORS))

# Definition/Creating the Cog
class Fun(commands.Cog):
  def __init__(self, vicious):
    self.vicious = vicious
    cog_name = self.__class__.__name__
    print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

# Cog Commands
  @commands.command(aliases=["dong"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def pp(ctx, *, user: discord.Member=None):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    if user is None:
        user = ctx.author
    size = random.randint(1, 14)
    pd = ""
    for _i in range(0, size):
        pd += "="
    embed = discord.Embed(description="`8{}D`".format(pd), color=color)
    embed.set_footer(text="{}'s PP size".format(user))
    await ctx.send(embed=embed)
  
  
  @commands.command()
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def meme(ctx):
    if ctx.message.author.id == blacklisted:
      return
    if ctx.message.author.vicious:
      return
    else:
      reddit = praw.Reddit(client_id=ID, user_agent=uagent, client_secret=reddit_key)
      meme = reddit.subreddit("memes").random()
      embed = discord.Embed(description="Meme from: `{}`".format(), color=color)
      embed.set_image(url=meme.url)
      embed.set_footer(text="{}", )
      await ctx.send(embed=embed)
      
# Cog Adding and Setup with Our Variable
def setup(vicious):
  vicious.add_cog(Fun(vicious))