# Imports
import discord, os, pymongo
from discord.ext import commands
from discord.ext.commands import check
from colorama import Fore as V

# ENV/Hidden Files
mongo_key = os.environ.get("key")
ID = os.environ.get("ID")

# Shortened
TiNy = V.LIGHTCYAN_EX
prefixx = os.environ.get("prefix")
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()
# Definitions
def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID


# MongoDB Key Startup
try:
  mongoDB = pymongo.MongoClient(mongo_key, tls=True, tlsAllowInvalidCertificates=False)
  blacklisted = mongoDB.get_database("Vicious").get_collection("Blacklisted")
  prefixes = mongoDB.get_database("Vicious").get_collection("Prefixes")
  premium = mongoDB.get_database("Vicious").get_collection("Premium")
except:
  print("{}[-] Invalid MongoDB Key".format(ERRORS))

def premium(ctx, guild_owner, serverid, user: discord.Member):
  database = [premium, prefixes]
  database.find_one({
    "guild_owner": guild_owner,
    "guildid": ctx.guildid, 
    "premium": premium 
  })

class Premium(commands.Cog):
  def __init__(self, vicious):
        self.vicious = vicious
        cog_name = self.__class__.__name__
        print("{}[+] Loaded Cog: {}".format(TiNy, cog_name))

# Cog Commands    
  @commands.command(aliases=["setprefix", "sp"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def changeprefix(ctx, prefix="$"):
    mongoDB.config.upsert({"guildid": ctx.guild.id, "_id": ctx.author.id }, {"$set": {"prefix": prefix}})
    pembed = discord.Embed(description="**__Changed Prefix:__** `{}`\n**__Default:__** `{}`".format(prefix, prefixx), color=color)
    pembed.set_footer(text="{}".format(ctx.author), icon_url=ctx.author.avatar_url)
    await ctx.send(embed=pembed)

  @commands.command(aliases=["rprefix", "rp"])
  @commands.cooldown(1, 5, commands.BucketType.user)
  @commands.cooldown(1, 2, commands.BucketType.guild)
  async def resetprefix(ctx):
    mongoDB.config.unset({"guildid": ctx.guild.id, "_id": ctx.author.id }, {"$set": {"prefix": 1}})
    pembed = discord.Embed(description="**__Resetted Prefix:__** `$`", color=color)
    pembed.set_footer(text="{}".format(ctx.author), icon_url=ctx.author.avatar_url)
    await ctx.send(embed=pembed)

# Cog Adding and Setup with Our Variable
def setup(vicious):
  vicious.add_cog(Premium(vicious))