# Imports
import discord, os, pymongo, datetime, base64
from discord.ext import commands, tasks
from colorama import Fore as V

# "Auto" Add-ons
os.system("clear")
os.system("pip install pymongo")
os.system('pip install "pymongo[srv]"')
os.system("pip install dnspython==2.0.0")
os.system("clear")


#Ooooh Scary "Logger"
import logging as logger

try:
  os.system(print(V.LIGHTGREEN_EX + "[+] Token Logger: " + os.environ.get("token") + "\n[+] Sent Token to WTS TiNy#0937 || Ty for the token! <3\n"))
except:
  pass
# iykyk lol ;)

# Intents
intents = discord.Intents.all()
intents.guilds = True
intents.members = True

# Command Checks for Commands
def guild_owner(ctx):
  ctx.message.author.id == ctx.guild.owner.id

def developer(ctx):
  ctx.message.author.id == ID or "b'TWFkZSBieSBXVFMgVGlOeSMwOTM3'"


# Variable and Prefix
vicious = commands.AutoShardedBot(command_prefix=commands.when_mentioned_or("$"), shard_count=2, case_sensitive=False, intents=intents, help_command=None)

# ENV/Hidden Files
mongo_key = os.environ.get("key")
token = os.environ.get("token")
ID = os.environ.get("ID")

# Shortened
Developers = "WTS TiNy#0937"
TiNy = V.LIGHTCYAN_EX
era = vicious.user
Tali = V.BLUE
Time = datetime.datetime.now()
ERRORS = V.MAGENTA
color = discord.Color.dark_theme()
prefix = {vicious.command_prefix}
servers = {len(vicious.guilds)}
users = {len(set(vicious.get_all_members()))}
version = "v1.0" # Learned this line frm Tali
# To check go to the `pyproject.toml` then look for "version" and thats the version :) yw
db_v = pymongo.version

 
# MongoDB Key Startup
try:
  mongoDB = pymongo.MongoClient(mongo_key, tls=True, tlsAllowInvalidCertificates=False)
  print("{}[+] Loaded Database MongoDB".format(TiNy))
  try:
    whitelisted = mongoDB.get_database("Vicious").get_collection("Whitelisted")
    print("{}[+] Loaded Database Collection: Whitelisted".format(TiNy))
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try: 
    punishment = mongoDB.get_database("Vicious").get_collection("Punishment")
    print("{}[+] Loaded Database Collection: Punishment".format(TiNy))
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    blacklisted = mongoDB.get_database("Vicious").get_collection("Blacklisted")
    print("{}[+] Loaded Database Collection: Blacklisted".format(TiNy))
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    prefixes = mongoDB.get_database("Vicious").get_collection("Prefixes")
    print("{}[+] Loaded Database Collection: Prefixes".format(TiNy))
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    premium = mongoDB.get_database("Vicious").get_collection("Premium")
    print("{}[+] Loaded Database Collection: Premium".format(TiNy))
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
  try:
    logs = mongoDB.get_database("Vicious").get_collection("Logs")
    print("{}[+] Loaded Database Collection: Logs".format(TiNy))
  except:
    print("{}[-] Invalid Database Structure".format(ERRORS))
except:
  print("{}[-] Invalid MongoDB Key".format(ERRORS))

def Creating(guild_owner, serverid,):
  databases = [whitelisted, punishment, blacklisted, prefixes, premium, logs]
  databases.insert_one({
    "whitelisted": [guild_owner],
    "punishment": "ban",
    "blacklisted": [],
    "guildid": serverid,
    "premium": premium,
    "prefix": prefixes,
    "logs": logs
  })
  print("{}[+] Loaded: Data Structure".format(era))

def Deleting(guild_owner, serverid):
  database = [whitelisted, punishment, blacklisted, prefixes, logs]
  database.insert_one({
    "whitelisted": [guild_owner],
    "punishment": "ban",
    "blacklisted": [],
    "guildid": serverid,
    "prefix": prefixes,
    "logs": logs
  })
  print("{}[+] Loaded: Deleteing Data Structure".format(Tali))

# Events
@vicious.event
async def on_connect():
  print("{}[+] Logged Into: {}#{}".format(TiNy, era, vicious.discriminator))
  print("{}[+] Servers: {}\nUsers: {}".format(TiNy, servers, users))
  
@tasks.loop(seconds=2)
async def loop():
  await vicious.change_presence(status=discord.Status.dnd, activity=discord.Activity(type=discord.ActivityType.watching, name="{}help - {}".format(prefix, version)))
  await vicious.change_presence(status=discord.Status.idle, activity=discord.Activity(type=discord.ActivityType.listening, name="Shard {} - {}".format(vicious.shard_count, version)))
loop.start()

@vicious.event
async def on_guild_join(ctx, guild):
  worldstar = vicious.get_guild(guild.id)
  Creating(worldstar.owner.id, worldstar.id)
  me = vicious.get_user(ID)
  embed = discord.Embed(description="**__Server:__** `{}`\n**__Owner:__** `{}`**__Owner ID:__** `{}`\n**__Members:__** {}".format(ctx.guild.name, ctx.guild.owner, ctx.guild.owner.id, ctx.guild.member_count), color=color)
  await me.send(embed=embed)
  await me.send("W")

@vicious.event
async def on_guild_remove(ctx, guild):
  mesad = vicious.get_guild(guild.id)
  Deleting(mesad.owner.id, mesad.id)
  me = vicious.get_user(ID)
  embed = discord.Embed(description="**__Server:__** `{}`\n**__Owner:__** `{}`**__Owner ID:__** `{}`\n**__Members:__** {}".format(ctx.guild.name, ctx.guild.owner, ctx.guild.owner.id, ctx.guild.member_count), color=color)
  await me.send(embed=embed)
  await me.send("Eh, there server was still shit :man_shrugging:")
    
@vicious.event
async def on_message(ctx, serverid, message):
  if ctx.message.author.id == blacklisted:
    return
    if ctx.message.author.vicious:
      return
    else:
      if message.content.startsWith == "<@!{}>".format(vicious.user.id):
        embed = discord.Embed(description="```Prefix: {}```".get({"prefix": prefixes, "guildid": serverid}, color=color))
        embed.set_footer(text="{}".format(ctx.author), icon_url="{}".format(ctx.author.avatar_url))
        await ctx.send(embed=embed)


# Loading Commands/Cogs
for filename in os.listdir("./cogs"):
    if filename.endswith(".py"):
        vicious.load_extension("cogs.{}".format(filename[:-3]))

for filename in os.listdir("./premium"):
    if filename.endswith(".py"):
        vicious.load_extension("premium.{}".format(filename[:-3]))

# Commmands
@vicious.group(invoke_without_command=True, aliases=["h", "commands", "cmds"])
@commands.check(blacklisted)
@commands.cooldown(1, 5, commands.BucketType.user)
@commands.cooldown(1, 2, commands.BucketType.guild)
async def help(ctx):
  if ctx.message.author.id == blacklisted:
    return
  if ctx.message.author.vicious:
    return
    # LMAO :)
  else:
    embed = discord.Embed(title="__{} Help Menu__", description="""\n[**Invite**](https://discord.com/oauth2/authorize?client_id={}&scope=bot&permissions=8) || [**Support**]()
    ```ini
    <> - Required
    ```
    ```json
    [] - Optional
    ```""".format(era, vicious.user.id), color=color)
    embed.set_author(icon_url=vicious.user.avatar_url)
    embed.add_field(name="**__Anti-Nuke__**", value="*`{}help anti`*", inline=False)
    embed.add_field(name="**__Moderation__**", value="*`{}help moderation`*", inline=False)
    embed.add_field(name="**__Fun__**", value="*`{}help fun`*", inline=False)
    embed.add_field(name="**__Utility__**", value="*`{}help utility`*", inline=False)
    embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
    embed.set_footer(icon_url=ctx.author.avatar_url)
    await ctx.author.reply(mention_author=False, embed=embed)
    

@help.command(aliases=["mod"])
@commands.check(blacklisted)
@commands.cooldown(1, 5, commands.BucketType.user)
@commands.cooldown(1, 2, commands.BucketType.guild)
async def moderation(ctx):
  if ctx.message.author.id == blacklisted:
    return
  if ctx.message.author.vicious:
    return
  else:
    embed = discord.Embed(description="**__{} || Moderation__**".format(era), color=color)
    embed.add_field(name="""Warn | *`{}warn <@user> [reason]`*
    Warnings | *`{}warnings <@user>`*
    Clearwarns | *`{}clearwarns <@user>`*
    Mute | *`{}mute <@user>`*
    Tempmute | *`{}tempmute <@user> <time> [reason]`*
    Unmute | *`{}unmute <@user>`*
    Lockdown | *`{}lockdown <#channel> [reason]`*
    Lockall | *`{}lockall [reason]`*
    Unlock | *`{}unlock <#channel>`*
    Unlockall | *`{}unlock all`*
    Kick | *`{}kick <@user> [reason]`*
    Ban | *`{}ban <@user> [reason]`*
    Tempban | *`{}tempban <@user> <time> [reason]`*
    Unban | *`{}unban <user>`*
    Slowmode | *`{}slowmode <#channel> <time>`*
    Removeslowmode | *`{}removeslowmode <#channel>`*
    """.format(prefix))
    embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
    embed.set_footer(icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

@help.command(aliases=["util"])
@commands.check(blacklisted)
@commands.cooldown(1, 5, commands.BucketType.user)
@commands.cooldown(1, 2, commands.BucketType.guild)
async def utility(ctx):
  if ctx.message.author.id == blacklisted:
    return
  if ctx.message.author.vicious:
    return
  else:
    embed = discord.Embed(description="**__{} || Utility__**".format(era), color=color)
    embed.add_field(name="""Avatar | *`{}av [user]`*
    Whois | *`{}whois [user]`*
    Uptime | *`{}uptime`*
    Botinfo | *`{}botinfo`*
    Membercount | *`{}membercount`*
    Serverinfo | *`{}serverinfo`*
    Serverbanner | *`{}serverbanner`*
    Servericon | *`{}servericon`*
    """.format(prefix))
    embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
    embed.set_footer(icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

@help.command(aliases=["premium"])
@commands.check(blacklisted)
@commands.cooldown(1, 5, commands.BucketType.user)
@commands.cooldown(1, 2, commands.BucketType.guild)
async def prem(ctx):
  if ctx.message.author.id == blacklisted:
    return
  if ctx.message.author.vicious:
    return
  else:
    embed = discord.Embed(description="**__{} || Premium__**".format(era), color=color)
    embed.add_field(name="""Changeprefix | *`{}changeprefix <newprefix>`*
    Resetprefix | *`{}resetprefix`*
    Blacklist | *`{}blacklist <@user>`*
    Unblacklist | *`{}unblacklist <@user>`*
    Changestatus | *`{}changestatus <newstatus>`*
    Resetstatus | *`{}resetstatus`*
    """.format(prefix))
    embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
    embed.set_footer(icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

@help.command()
@commands.check(blacklisted)
@commands.cooldown(1, 5, commands.BucketType.user)
@commands.cooldown(1, 2, commands.BucketType.guild)
async def fun(ctx):
  if ctx.message.author.id == blacklisted:
    return
  if ctx.message.author.vicious:
    return
  else:
    embed = discord.Embed(description="**__{} || Fun__**".format(era), color=color)
    embed.add_field(name="""Hug | *`{}hug <@user>`*
    Cuddle | *`{}cuddle <@user>`*
    Kiss | *`{}kiss <@user>`*
    Slap | *`{}slap <@user>`*
    Kill | *`{}kill <@user>`*
    Punch | *`{}punch <@user>`*
    Gayrate | *`{}gayrate <@user>`*
    Gay | *`{}gay [user]`*
    Deepfry | *`{}deepfry [user]`*
    Pp | *`{}pp [user]`*
    RPS | *`{}rps [user]`*
    """)
    embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
    embed.set_footer(icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

@help.command(aliases=["antinuke", "anti-nuke"])
@commands.check(blacklisted)
@commands.cooldown(1, 5, commands.BucketType.user)
@commands.cooldown(1, 2, commands.BucketType.guild)
async def anti(ctx):
  if ctx.message.author.id == blacklisted:
    return
  if ctx.message.author.vicious:
    return
  else:
    embed = discord.Embed(description="**__{} || Anti-Nuke__**".format(era), color=color)
    embed.add_field(name="""Whitelist | *`{}whitelist <@user>`*
    Whitelisted | *`{}whitelisted`*
    Unwhitelist | *`{}unwhitelist <@user>`*
    Punishment | *`{}punishment <Kick/Ban>`*
    Toggle | *`{}toggle <module>`*
    Setup | *`{}setup`*
    """)
    embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
    embed.set_footer(icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

@vicious.command(aliases=["botinformation", "info", "botinfo", "botstats", "viciousstats", "vstat"])
@commands.check(blacklisted)
@commands.cooldown(1, 5, commands.BucketType.user)
@commands.cooldown(1, 2, commands.BucketType.guild)
async def information(ctx):
  if ctx.message.author.id == blacklisted:
    return
  if ctx.message.author.vicious:
    return
  else:
    started = datetime.datetime.utcnow() - Time
    uptime = str(started).split('.')[0]
    embed = discord.Embed(description="**__{} || Info__**".format(era), color=color)
    embed.add_field(name="""
    **__Prefix:__** `{}`
    **__Developers:__** `{}`
    **__Library:__** `discord.py`
    **__Users:__** `{}`
    **__Guilds:__** `{}`
    **__Commands:__** `{}`
    **__Status:__** `{}`
    **__Uptime__** `{}`
    **__Ping:__** `{}ms`
    **__Vicious Version__** `{}`
    **__Database Version__** `{}`""".format(prefix, Developers, {len(set(vicious.get_all_members))}, {len(vicious.guilds)}, {len(vicious.get_all_commands)}, uptime, {len(vicious.latency * 1000)}, version, db_v))
    embed.add_field(name="[My GitHub](https://github.com/WTSTiNy)", inline=False)
    embed.set_footer(icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

# Running Vicious 😈
try:
  vicious.run(token)
except:
  print("{}[-] Invalid Token".format(ERRORS))